import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <form action="#" (submit)="submitHandler(myForm, $event)" #myForm="ngForm" novalidate>
      <label>Shipment : 
          <input type="text" #shipment="ngModel" [pattern]="shippattern" [(ngModel)]="selection.shipment" name="shipment">
          <span *ngIf="shipment.invalid && shipment.touched">Shipment is wrong</span>
          <span *ngIf="shipment.errors?.pattern">Pattern is wrong</span>
          </label>
          <br>
          <label>Package : 
          <input type="text" #package="ngModel" [(ngModel)]="selection.package" name="package">
          <span *ngIf="package.invalid && package.touched">Package is wrong</span>
          </label>
          <br>
          <label>Order No : 
          <input type="text" #orderno="ngModel" [(ngModel)]="selection.orderno" name="orderno">
          <span *ngIf="orderno.invalid && orderno.touched">Order is wrong</span>
          </label>
          <br>
          <label>POTO : 
          <input type="text" #poto="ngModel" [(ngModel)]="selection.poto" name="poto">
          <span *ngIf="poto.invalid && poto.touched">POTO is wrong</span>
          </label>
          <br>
          <label>Product : 
          <input type="text" #productid="ngModel" [(ngModel)]="selection.productid" name="productid">
          <span *ngIf="productid.invalid && productid.touched">Product is wrong</span>
      </label>
      <br>
      <button type="submit" [disabled]="myForm.invalid">search</button>
    </form>
    <hr>
    <ul>
      <li *ngFor="let item of data">{{ item | json }}</li>
    </ul>
    <hr>
    <ul>
      <li *ngFor="let item of resultdata">{{ item | json }}</li>
    </ul>
  `,
  styles: [`
  label{
    width : 150px;
    display : inline-block
  }
  `]
})
export class AppComponent {
  selection = {};
  shippattern = "[a-zA-Z]{7}[0-9]{5}";
  resultdata = [];
  searchterms = [];
  data = [
    {
      shipment: "SHIPASN00001",
      package: "00000000000000000002",
      orderno: "OR129",
      poto: "PP20180918A",
      productid: "100001"
    },
    {
      shipment: "SHIPASN00002",
      package: "00000000000000000002",
      orderno: "OR130",
      poto: "PP20180918A",
      productid: "100002"
    },
    {
      shipment: "SHIPASN00003",
      package: "00000000000000000003",
      orderno: "OR130",
      poto: "PP20180918A",
      productid: "100003"
    },
    {
      shipment: "SHIPASN00004",
      package: "00000000000000000004",
      orderno: "OR130",
      poto: "PP20180918A",
      productid: "100004"
    }
  ];

  submitHandler(formdata, evt) {
    evt.preventDefault();
    this.searchterms = [];
    this.resultdata = [];
    // console.log(formdata.form.controls, formdata.form.value); 
    // let loop for every form value user has filled 
    for(let prop in formdata.form.value){
    // console.log(formdata.form.value[prop]);
    // now if the user has not typed any value it will be undefined
        if(formdata.form.value[prop]){
          // console.log(prop); // name of the property
          // console.log(formdata.form.value[prop]); // value of the property
          this.searchterms.push({ [prop] : formdata.form.value[prop] }); //created as an object and pushed in searchterms array
          // now we shall loop for the user's endered value to search in the data
        }

          for(let i = 0; i < this.data.length; i++){
            /* or search */
            if(this.data[i][prop]+"".toLowerCase() === formdata.form.value[prop]+"".toLocaleLowerCase()){
              // console.log(this.data[i])
              this.resultdata.push(this.data[i]);
            }
          };
        };
    if(this.resultdata.length >= 0 ){
      // lets find uique
       this.resultdata = Array.from(new Set(this.resultdata)) 
    }else{
      this.searchterms = [];
      alert("no data");
    }
    console.log(this.searchterms);
  }
   
}

/*

var filteredArr = firstArr.filter(el => secondArr.indexOf(el) === -1);

*/